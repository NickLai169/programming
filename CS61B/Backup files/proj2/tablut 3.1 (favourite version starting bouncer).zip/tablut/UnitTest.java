package tablut;

import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;
import ucb.junit.textui;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

import static tablut.Square.*;
import static tablut.Piece.*;
import static tablut.Move.*;
import static tablut.AI.*;

/** The suite of all JUnit tests for the enigma package.
 *  @author Definitely-Not-Nick
 */
public class UnitTest {

    /** Run the JUnit tests in this package. Add xxxTest.class entries to
     *  the arguments of runClasses to run other JUnit tests. */
    public static void main(String[] ignored) {
        textui.runClasses(UnitTest.class);
    }

    public void printTempBoard(Piece[][] tempBoard) {
        for (Piece[] row: tempBoard) {
            for (Piece item: row) {
                System.out.print(item + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    public Piece[][] copyBoard(Piece[][] board) {
        Piece[][] retBoard = new Piece[board.length][board[0].length];

        for (int row = 0; row < board.length; row += 1) {
            for (int col = 0; col < board[0].length; col += 1) {
                retBoard[row][col] = board[row][col];
            }
        }

        return retBoard;
    }

    public boolean boardEqual(Piece[][] board1, Piece[][] board2) {
        for (int row = 0; row < board1.length; row += 1) {
            for (int col = 0; col < board1[0].length; col += 1) {
                if (board1[row][col] != board2[row][col]) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean boardNonEqual(Piece[][] board1, Piece[][] board2) {
        for (int row = 0; row < board1.length; row += 1) {
            for (int col = 0; col < board1[0].length; col += 1) {
                if (board1[row][col] != board2[row][col]) {
                    return true;
                }
            }
        }
        return false;
    }

    public void printMoveList(List<Move> moveList) {
        String tempSquare = "h10";
        for (Move m: moveList) {
            if (!tempSquare.equals(m.toString().substring(0, 2))) {
                System.out.println();
                tempSquare = m.toString().substring(0, 2);
            }
            tempSquare = m.toString().substring(0, 2);
            System.out.print(m + " ");
        }
    }

    public Piece[][] initializeBoardFromString(String inputString) {
        Piece[][] retBoard = new Piece[9][9];
        Scanner inputStringScanner = new Scanner(inputString);
        String nextChar = inputStringScanner.next();
        for (int row = 0; row < 9; row += 1){
            for (int col = 0; col < 9; col += 1) {
                if (nextChar.equals("-")) {
                    retBoard[row][col] = EMPTY;
                } else if (nextChar.equals("W")) {
                    retBoard[row][col] = WHITE;
                } else if (nextChar.equals("B")) {
                    retBoard[row][col] = BLACK;
                } else if (nextChar.equals("K")) {
                    retBoard[row][col] = KING;
                } else {
                    System.out.println("I FUCKED UP: |" + nextChar + "|");
                }
                if (inputStringScanner.hasNext()) {
                    nextChar = inputStringScanner.next();
                }
            }
        }
        return retBoard;
    }

    @Test
    public void textTest() {
        HashSet<String> testHash = new HashSet<String>();

        testHash.add("oooxxxooo");
        testHash.add("oooxoxooo");
        testHash.add("ooooxoooo");

        String tempString = "";
        for (int i = 0; i < 10; i += 1) {
            tempString = tempString + i;
        }
        testHash.add(tempString);

        System.out.println(testHash.contains("0123456789"));
        System.out.println();

        testHash.remove("0123456789");
        System.out.println(testHash.contains("0123456789"));
        System.out.println(testHash);
    }

    @Test
    public void testBoardboardInitialization() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        /* These lines below check the first row of the board*/
        for (int i = 0; i < 3; i += 1) {
            assertSame(EMPTY, theBoard[0][i]);
        }
        for (int i = 3; i < 6; i += 1) {
            assertSame(BLACK, theBoard[0][i]);
        }
        for (int i = 6; i < 9; i += 1) {
            assertSame(EMPTY, theBoard[0][i]);
        }

        /* These lines below check the middle row of the board*/
        for (int i = 0; i < 2; i += 1) {
            assertSame(BLACK, theBoard[4][i]);
        }
        for (int i = 2; i < 4; i += 1) {
            assertSame(WHITE, theBoard[4][i]);
        }
        assertSame(KING, theBoard[4][4]);
        for (int i = 5; i < 7; i += 1) {
            assertSame(WHITE, theBoard[4][i]);
        }
        for (int i = 7; i < 9; i += 1) {
            assertSame(BLACK, theBoard[4][i]);
        }

        /* These lines below check the last row of the board*/
        for (int i = 0; i < 3; i += 1) {
            assertSame(EMPTY, theBoard[8][i]);
        }
        for (int i = 3; i < 6; i += 1) {
            assertSame(BLACK, theBoard[8][i]);
        }
        for (int i = 6; i < 9; i += 1) {
            assertSame(EMPTY, theBoard[8][i]);
        }
    }

    @Test
    public void testBoardInitialization2() {
        Board myBoard = new Board();
        myBoard.init();

        Piece[][] theBoard = myBoard.board();

        /* These lines below check the first column of the board*/
        for (int i = 0; i < 3; i += 1) {
            assertSame(EMPTY, theBoard[i][0]);
        }
        for (int i = 3; i < 6; i += 1) {
            assertSame(BLACK, theBoard[i][0]);
        }
        for (int i = 6; i < 9; i += 1) {
            assertSame(EMPTY, theBoard[i][0]);
        }

        /* These lines below check the middle column of the board*/
        for (int i = 0; i < 2; i += 1) {
            assertSame(BLACK, theBoard[i][4]);
        }
        for (int i = 2; i < 4; i += 1) {
            assertSame(WHITE, theBoard[i][4]);
        }
        assertSame(KING, theBoard[4][4]);
        for (int i = 5; i < 7; i += 1) {
            assertSame(WHITE, theBoard[i][4]);
        }
        for (int i = 7; i < 9; i += 1) {
            assertSame(BLACK, theBoard[i][4]);
        }

        /* These lines below check the last column of the board*/
        for (int i = 0; i < 3; i += 1) {
            assertSame(EMPTY, theBoard[8][i]);
        }
        for (int i = 3; i < 6; i += 1) {
            assertSame(BLACK, theBoard[8][i]);
        }
        for (int i = 6; i < 9; i += 1) {
            assertSame(EMPTY, theBoard[8][i]);
        }
    }

    @Test
    public void testBoardkingPosition() {
        Board myBoard = new Board();
        myBoard.init();

        myBoard.setMoveLimit(12);
        assertEquals(myBoard.moveCount(), 0);

        /* The king should be dead centre at initializatio */
        assertSame(myBoard.kingPosition(), sq(4, 4));

        Piece[][] theBoard = myBoard.board();
        /* Remove the king and plot him in bottom-right corner*/
        theBoard[4][4] = EMPTY;
        theBoard[8][8] = KING;

        assertSame(myBoard.kingPosition(), sq(8, 8));

        /* Remove the king */
        theBoard[8][8] = EMPTY;

        try {
            myBoard.kingPosition();
            Utils.error("There was supposed to be an error");
        } catch (IllegalArgumentException e) {
            theBoard[4][4] = KING;
        }
    }

    @Test
    public void testBoardget() {
        Board myBoard = new Board();
        myBoard.init();
        myBoard.setMoveLimit(12);

        assertEquals(KING, myBoard.get(4, 4));

        /* These lines below check the first row of the board*/
        for (int i = 0; i < 3; i += 1) {
            assertSame(EMPTY, myBoard.get(i, 0));
        }
        for (int i = 3; i < 6; i += 1) {
            assertSame(BLACK, myBoard.get(i, 0));
        }
        for (int i = 6; i < 9; i += 1) {
            assertSame(EMPTY, myBoard.get(i, 0));
        }

        /* These lines below check the middle column of the board*/
        for (int i = 0; i < 2; i += 1) {
            assertSame(BLACK, myBoard.get(4, i));
        }
        for (int i = 2; i < 4; i += 1) {
            assertSame(WHITE, myBoard.get(4, i));
        }
        assertSame(KING, myBoard.get(4, 4));
        for (int i = 5; i < 7; i += 1) {
            assertSame(WHITE, myBoard.get(4, i));
        }
        for (int i = 7; i < 9; i += 1) {
            assertSame(BLACK, myBoard.get(4, i));
        }
    }

    @Test
    public void testBoardisUnblockedMove() {
        Board myBoard = new Board();
        myBoard.init();
        myBoard.setMoveLimit(12);

        /* Testing capable of moving from from to to*/
        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(0, 0), sq(0, 2)));
        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(0, 0), sq(2, 0)));
        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(3, 0), sq(0, 0)));
        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(0, 3), sq(0, 0)));

        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(4, 5), sq(1, 5)));
        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(4, 5), sq(7, 5)));
        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(3, 7), sq(0, 7)));
        assertTrue("This was meant to be true",
                myBoard.isUnblockedMove(sq(5, 8), sq(8, 8)));

        /* testing spaces incapable of moving from from to to*/
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(4, 4), sq(4, 5)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(4, 4), sq(5, 4)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(4, 4), sq(4, 3)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(4, 4), sq(3, 4)));
    }

    @Test
    public void testBoardIsUnblocked2() {
        Board myBoard = new Board();
        myBoard.init();
        myBoard.setMoveLimit(12);

        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(0, 4), sq(0, 0)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(4, 0), sq(0, 0)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(8, 4), sq(8, 8)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(4, 8), sq(8, 8)));

        /* testing spaces not even on the same row or column*/
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(1, 1), sq(2, 2)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(4, 5), sq(6, 7)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(0, 8), sq(3, 5)));
        assertFalse("this was meant to be false",
                myBoard.isUnblockedMove(sq(8, 8), sq(7, 7)));

        /* testing spaces that are the same*/
        assertFalse("This was meant to be true",
                myBoard.isUnblockedMove(sq(4, 4), sq(4, 4)));
        assertFalse("This was meant to be true",
                myBoard.isUnblockedMove(sq(3, 5), sq(3, 5)));
        assertFalse("This was meant to be true",
                myBoard.isUnblockedMove(sq(0, 0), sq(0, 0)));
        assertFalse("This was meant to be true",
                myBoard.isUnblockedMove(sq(8, 8), sq(8, 8)));
    }

    @Test
    public void testPut() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        myBoard.put(KING, sq(0, 0));
        assertSame(myBoard.get(0, 0), KING);

        myBoard.put(BLACK, sq(8, 0));
        assertSame(myBoard.get(8, 0), BLACK);
    }

    @Test
    public void testBoardIsLegal() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        /** Checking moves that can be made by black.*/
        assertTrue(myBoard.isLegal(sq(3, 0), sq(0, 0)));
        assertTrue(myBoard.isLegal(sq(3, 0), sq(3, 3)));

        /** Checking moves that can't be made by black.*/
        assertFalse(myBoard.isLegal(sq(3, 0), sq(3, 4)));
        assertFalse(myBoard.isLegal(sq(3, 0), sq(4, 0)));

        /** Checking moves that can be made by white, but shouldn't be made because it's black's turn.*/
        assertFalse(myBoard.isLegal(sq(4, 3), sq(6, 3)));
        assertFalse(myBoard.isLegal(sq(4, 6), sq(0, 6)));

        /** Checking the king*/
        assertFalse(myBoard.isLegal(sq(4, 4), sq(4, 3)));

        /** Checking the king after a square around it has been removed*/
        myBoard.put(EMPTY, sq(4, 3));
        assertFalse(myBoard.isLegal(sq(4, 4), sq(0, 6)));
    }

    @Test
    public void testBoardRepeatedPosition() {
        Board myBoard = new Board();
        myBoard.init();

        assertFalse(myBoard.repeatedPosition());

        myBoard.put(BLACK, sq(0,0));
        myBoard.checkRepeated();
        myBoard.recordBoardState();
        assertFalse(myBoard.repeatedPosition());

        myBoard.put(EMPTY, sq(0,0));
        myBoard.checkRepeated();
        myBoard.recordBoardState();
        assertTrue(myBoard.repeatedPosition());


        myBoard = new Board();
        myBoard.init();

        myBoard.put(BLACK, sq(4,3));
        myBoard.checkRepeated();
        myBoard.recordBoardState();
        assertFalse(myBoard.repeatedPosition());

        myBoard.put(BLACK, sq(3,4));
        myBoard.checkRepeated();
        myBoard.recordBoardState();
        assertFalse(myBoard.repeatedPosition());

        myBoard.put(WHITE, sq(4,3));
        myBoard.checkRepeated();
        myBoard.recordBoardState();
        assertFalse(myBoard.repeatedPosition());

        myBoard.put(WHITE, sq(3,4));
        myBoard.checkRepeated();
        myBoard.recordBoardState();
        assertTrue(myBoard.repeatedPosition());
    }

    @Test
    public void testBoardMoveMaking1() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        myBoard.makeMove(sq(3, 0), sq(0, 0));
        assertFalse(myBoard.repeatedPosition());
        assertSame(theBoard[0][0], BLACK);

        myBoard.makeMove(sq(4, 2), sq(0, 2));
        assertSame(theBoard[2][0], WHITE);
        assertFalse(myBoard.repeatedPosition());

        myBoard.makeMove(sq(0, 0), sq(0, 1));
        assertSame(theBoard[1][0], BLACK);
        assertSame(theBoard[2][0], EMPTY);
        assertFalse(myBoard.repeatedPosition());

        myBoard.makeMove(sq(4, 3), sq(4, 2));
        assertSame(theBoard[2][4], WHITE);
        assertFalse(myBoard.repeatedPosition());

        myBoard.makeMove(sq(5, 8), sq(5, 5));
        assertSame(theBoard[5][5], BLACK);
        assertSame(theBoard[8][5], EMPTY);
        assertFalse(myBoard.repeatedPosition());

        myBoard.makeMove(sq(4, 2), sq(0, 2));
        assertSame(theBoard[1][0], BLACK);
        assertSame(theBoard[2][0], WHITE);
        assertSame(theBoard[3][0], BLACK);
        assertFalse(myBoard.repeatedPosition());

        myBoard.makeMove(sq(5, 5), sq(5, 8));
        assertSame(theBoard[8][5], BLACK);
        assertSame(theBoard[5][5], EMPTY);
        assertFalse(myBoard.repeatedPosition());

        myBoard.makeMove(sq(0, 2), sq(4, 2));
        assertSame(theBoard[2][4], WHITE);
        assertTrue(myBoard.repeatedPosition());

        assertSame(myBoard.winner(), BLACK);
        assertEquals(8, myBoard.moveCount());
    }

    @Test
    public void testBoardMoveMaking2() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        myBoard.makeMove(sq(0, 3), sq(3, 3));
        myBoard.makeMove(sq(4, 3), sq(7, 3));
        assertSame(BLACK, theBoard[3][3]);
        assertSame(EMPTY, theBoard[3][0]);
        assertSame(WHITE, theBoard[3][7]);
        assertSame(EMPTY, theBoard[3][4]);

        myBoard.makeMove(sq(0, 5), sq(3, 5));
        assertSame(BLACK, theBoard[5][3]);
        assertSame(EMPTY, theBoard[4][3]);

        myBoard.makeMove(sq(4, 5), sq(7, 5));
        myBoard.makeMove(sq(8, 4), sq(7, 4));
        assertSame(WHITE, theBoard[5][7]);
        assertSame(BLACK, theBoard[4][7]);
        assertSame(EMPTY, theBoard[4][8]);

        Board copiedBoard = new Board(myBoard);

        copiedBoard.makeMove(sq(2, 4), sq(2, 0));
        copiedBoard.makeMove(sq(5, 8), sq(5, 5));

        assertFalse(copiedBoard.repeatedPosition());
        assertNull(copiedBoard.winner());

        myBoard.makeMove(sq(2, 4), sq(2, 0));
        myBoard.makeMove(sq(5, 8), sq(5, 5));
        myBoard.makeMove(sq(6, 4), sq(6, 0));
        myBoard.makeMove(sq(3, 3), sq(5, 3));
        assertSame(EMPTY, theBoard[4][5]);

        myBoard.makeMove(sq(4, 4), sq(3, 4));
        myBoard.makeMove(sq(5, 3), sq(3, 3));
        assertSame(KING, theBoard[4][3]);

        /* This below move is actually illegal*/
        try {
            myBoard.makeMove(sq(4, 6), sq(4, 4));
        } catch (IllegalArgumentException e) {
            System.out.println(myBoard);
            System.out.println(sq(4, 6) + " to " + sq(4, 4)
                    + " was actually illegal, so we threw and error");
        }

        myBoard.makeMove(sq(4, 6), sq(3, 6));
        assertSame(EMPTY, theBoard[5][3]);

        myBoard.makeMove(sq(5, 5), sq(3, 5));
        assertSame(BLACK, theBoard[5][3]);

        myBoard.makeMove(sq(7, 3), sq(7, 0));

        assertNull(myBoard.winner());
        myBoard.makeMove(sq(1, 4), sq(2, 4));
        assertEquals(BLACK, myBoard.winner());
        assertFalse(myBoard.repeatedPosition());

        Piece[][] tempBoard1 = myBoard.historyStack.pop();
        Piece[][] tempBoard2 = myBoard.historyStack.pop();
        Piece[][] tempBoard3 = myBoard.historyStack.pop();
        assertEquals(KING, tempBoard1[4][3]);
        assertEquals(KING, tempBoard2[4][3]);
        assertEquals(WHITE, tempBoard2[3][7]);
        assertEquals(EMPTY, tempBoard3[5][3]);
        assertEquals(BLACK, tempBoard3[5][5]);
    }

    @Test
    public void testBoardUndoMoves() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        myBoard.undo();

        /* Note that this game is identical to the one played in testBoardMoveMaking2*/
        myBoard.makeMove(sq(0, 3), sq(3, 3));
        myBoard.makeMove(sq(4, 3), sq(7, 3));
        myBoard.makeMove(sq(0, 5), sq(3, 5));
        myBoard.makeMove(sq(4, 5), sq(7, 5));
        myBoard.makeMove(sq(8, 4), sq(7, 4));
        myBoard.makeMove(sq(2, 4), sq(2, 0));
        myBoard.makeMove(sq(5, 8), sq(5, 5));
        myBoard.makeMove(sq(6, 4), sq(6, 0));
        myBoard.makeMove(sq(3, 3), sq(5, 3));
        myBoard.makeMove(sq(4, 4), sq(3, 4));
        myBoard.makeMove(sq(5, 3), sq(3, 3));
        myBoard.makeMove(sq(4, 6), sq(3, 6));
        myBoard.makeMove(sq(5, 5), sq(3, 5));
        myBoard.makeMove(sq(7, 3), sq(7, 0));
        myBoard.makeMove(sq(1, 4), sq(2, 4));

        assertEquals(BLACK, myBoard.winner());
        assertFalse(myBoard.repeatedPosition());

        myBoard.undo();

        Board newBoard = new Board(myBoard);
        theBoard = newBoard.board();

        assertEquals(null, newBoard.winner());
        assertEquals(KING, theBoard[4][3]);
        assertEquals(WHITE, theBoard[0][7]);
        assertFalse(newBoard.repeatedPosition());
        assertEquals(14, newBoard.moveCount());

        newBoard.undo();
        assertEquals(WHITE, theBoard[3][7]);
        assertFalse(newBoard.repeatedPosition());
        assertEquals(13, newBoard.moveCount());

        for (int i = 0; i < 30; i += 1) {
            newBoard.undo();
        }

        /* The board should now be in its initial state*/
        assertEquals(0, newBoard.moveCount());
        assertEquals(1, newBoard.previousBoardStates.size());
        assertEquals(0, newBoard.historyStack.size());
        assertFalse(newBoard.repeatedPosition());
        assertNull(newBoard.winner());
    }

    @Test
    public void testBoardClearUndo() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        myBoard.makeMove(sq(0, 3), sq(3, 3));
        myBoard.makeMove(sq(4, 3), sq(7, 3));
        myBoard.makeMove(sq(0, 5), sq(3, 5));
        myBoard.makeMove(sq(4, 5), sq(7, 5));
        myBoard.makeMove(sq(8, 4), sq(7, 4));
        myBoard.makeMove(sq(2, 4), sq(2, 0));
        myBoard.makeMove(sq(5, 8), sq(5, 5));
        myBoard.makeMove(sq(6, 4), sq(6, 0));
        myBoard.makeMove(sq(3, 3), sq(5, 3));
        myBoard.makeMove(sq(4, 4), sq(3, 4));
        myBoard.makeMove(sq(5, 3), sq(3, 3));
        myBoard.makeMove(sq(4, 6), sq(3, 6));
        myBoard.makeMove(sq(5, 5), sq(3, 5));
        myBoard.makeMove(sq(7, 3), sq(7, 0));
        myBoard.makeMove(sq(1, 4), sq(2, 4));

        Piece[][] finalBoard = copyBoard(theBoard);
        myBoard.undo();
        myBoard.undo();
        Piece[][] undoneBoard = copyBoard(theBoard);
        assertFalse(myBoard.repeatedPosition());

        assert boardNonEqual(finalBoard, undoneBoard);
        assert boardEqual(undoneBoard, myBoard.board());

        myBoard.makeMove(sq(7, 3), sq(7, 0));
        myBoard.makeMove(sq(1, 4), sq(2, 4));
        finalBoard = copyBoard(theBoard);
        assert boardEqual(finalBoard, myBoard.board());
        assertFalse(myBoard.repeatedPosition());

        myBoard.clearUndo();
        myBoard.undo();
        myBoard.undo();
        assert boardEqual(finalBoard, myBoard.board());

        myBoard.printBoard();
    }

    @Test
    public void testBoardLegalMovesBlack() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        myBoard.printBoard();
        List<Move> legalMoveList = myBoard.legalMoves(BLACK);

        printMoveList(legalMoveList);

        /* A viable move for white*/
        assertFalse(legalMoveList.contains(mv(sq(2, 4), sq(2, 0))));
        assertFalse(legalMoveList.contains(mv(sq(4, 3), sq(1, 3))));

        /* A viable move for an empty square*/
        assertFalse(legalMoveList.contains(mv(sq(0, 0), sq(0, 2))));
        assertFalse(legalMoveList.contains(mv(sq(5, 5), sq(5, 6))));

        /* A non viable move for white*/
        assertFalse(legalMoveList.contains(mv(sq(4, 4), sq(4, 5))));
        assertFalse(legalMoveList.contains(mv(sq(4, 5), sq(8, 5))));

        /* A non viable move for an empty square*/
        assertFalse(legalMoveList.contains(mv(sq(8, 0), sq(4, 0))));
        assertFalse(legalMoveList.contains(mv(sq(8, 8), sq(7, 7))));

        /* A non-viable move for black*/
        assertFalse(legalMoveList.contains(mv(sq(0, 3), sq(1, 2))));
        assertFalse(legalMoveList.contains(mv(sq(5, 0), sq(5, 4))));
        assertFalse(legalMoveList.contains(mv(sq(8, 3), sq(1, 3))));

        /* A viable move for black*/
        assertTrue(legalMoveList.contains(mv(sq(3, 0), sq(3, 3))));
        assertTrue(legalMoveList.contains(mv(sq(7, 4), sq(7, 8))));
    }

    @Test
    public void testBoardLegalMovesWhite() {
        Board myBoard = new Board();
        myBoard.init();
        Piece[][] theBoard = myBoard.board();

        myBoard.makeMove(sq(0, 3), sq(3, 3));
        myBoard.makeMove(sq(4, 3), sq(7, 3));
        myBoard.makeMove(sq(0, 5), sq(3, 5));
        myBoard.makeMove(sq(4, 5), sq(7, 5));
        myBoard.makeMove(sq(8, 4), sq(7, 4));
        myBoard.makeMove(sq(2, 4), sq(2, 0));
        myBoard.makeMove(sq(5, 8), sq(5, 5));
        myBoard.makeMove(sq(6, 4), sq(6, 0));
        myBoard.makeMove(sq(3, 3), sq(5, 3));
        myBoard.makeMove(sq(4, 4), sq(3, 4));
        myBoard.makeMove(sq(5, 3), sq(3, 3));

        myBoard.printBoard();
        List<Move> legalMoveList = myBoard.legalMoves(WHITE);

        printMoveList(legalMoveList);

        /* A non-viable move for white*/
        assertFalse(legalMoveList.contains(mv(sq(7, 5), sq(4, 5))));
        assertFalse(legalMoveList.contains(mv(sq(4, 2), sq(4, 1))));
        assertFalse(legalMoveList.contains(mv(sq(4, 2), sq(4, 4))));
        assertFalse(legalMoveList.contains(mv(sq(4, 6), sq(4, 4))));

        /* A non-viable move for the King*/
        assertFalse(legalMoveList.contains(mv(sq(3, 4), sq(1, 4))));
        assertFalse(legalMoveList.contains(mv(sq(3, 4), sq(3, 2))));
        assertFalse(legalMoveList.contains(mv(sq(3, 4), sq(4,5))));
        assertFalse(legalMoveList.contains(mv(sq(3, 4), sq(1, 4))));

        /* A non-viable move for black*/
        assertFalse(legalMoveList.contains(mv(sq(1, 4), sq(4, 4))));
        assertFalse(legalMoveList.contains(mv(sq(0, 4), sq(1, 4))));

        /* A viable move for black*/
        assertFalse(legalMoveList.contains(mv(sq(5, 5), sq(4, 5))));
        assertFalse(legalMoveList.contains(mv(sq(8, 3), sq(8, 0))));

        /* A viable move for white*/
        assertTrue(legalMoveList.contains(mv(sq(4, 6), sq(4, 3))));
        assertTrue(legalMoveList.contains(mv(sq(6, 0), sq(6, 8))));

        /* A viable move for the King*/
        assertTrue(legalMoveList.contains(mv(sq(3, 4), sq(4, 4))));
        assertTrue(legalMoveList.contains(mv(sq(3, 4), sq(6, 4))));
    }

    /** Now we begin testing the AI :D*/

    @Test
    public void textTestAI() {
        AI myAI = new AI();

        System.out.println(Integer.MAX_VALUE);
    }

    @Test
    public void testKingWalker() {
        AI myAI = new AI();
        Board myBoard = new Board();
        Piece[][] theBoard = myBoard.board();

        int firstPos = myAI.kingWalker(theBoard, sq(4, 4), 243, new HashSet<Square>(), 4);
        assertEquals(0, firstPos);

        myBoard.makeMove(sq(0, 3), sq(3, 3));
        myBoard.makeMove(sq(4, 3), sq(7, 3));

        int secondPos = myAI.kingWalker(theBoard, sq(4, 4), 243, new HashSet<Square>(), 4);
        assertEquals(45, secondPos);
        myBoard.makeMove(sq(0, 5), sq(3, 5));
        myBoard.makeMove(sq(4, 5), sq(7, 5));
        myBoard.makeMove(sq(8, 4), sq(7, 4));
        myBoard.makeMove(sq(2, 4), sq(2, 0));
        myBoard.makeMove(sq(5, 8), sq(5, 5));
        myBoard.makeMove(sq(6, 4), sq(6, 0));
        myBoard.makeMove(sq(3, 3), sq(5, 3));
        myBoard.makeMove(sq(4, 4), sq(3, 4));

        int thirdPos = myAI.kingWalker(theBoard, sq(3, 4), 243, new HashSet<Square>(),4);

        myBoard.makeMove(sq(5, 3), sq(3, 3));

        assertFalse(myAI.canReachEdge(theBoard, sq(3,4), 0));
        assertFalse(myAI.canReachEdge(theBoard, sq(3,4), 1));
        assertFalse(myAI.canReachEdge(theBoard, sq(3,4), 2));
        assertFalse(myAI.canReachEdge(theBoard, sq(3,4), 3));

        myBoard.makeMove(sq(3, 4), sq(2, 4));

        int fourthPos = myAI.kingWalker(theBoard, sq(2, 4), 243, new HashSet<Square>(), 4);

        assertFalse(myAI.canReachEdge(theBoard, sq(2,4), 0));
        assertFalse(myAI.canReachEdge(theBoard, sq(2,4), 1));
        assertTrue(myAI.canReachEdge(theBoard, sq(2,4), 2));
        assertFalse(myAI.canReachEdge(theBoard, sq(2,4), 3));

        myBoard.makeMove(sq(3, 3), sq(3, 2));
        myBoard.makeMove(sq(2, 4), sq(2, 5));

        assertFalse(myAI.canReachEdge(theBoard, sq(2,5), 0));
        assertFalse(myAI.canReachEdge(theBoard, sq(2,5), 1));
        assertTrue(myAI.canReachEdge(theBoard, sq(2,5), 2));
        assertTrue(myAI.canReachEdge(theBoard, sq(2,5), 3));

        int fifthPos = myAI.kingWalker(theBoard, sq(2, 5), 243, new HashSet<Square>(), 4);

        assertTrue(firstPos < secondPos);
        assertTrue(secondPos < thirdPos);
        assertTrue(thirdPos < fourthPos);
        assertTrue(fourthPos < fifthPos);
    }

    @Test
    public void testAnalyzeBoards() {
        AI myAI = new AI();
        Board myBoard = new Board();

//        int runningWhite = myAI.analyzeBoardWhite(myBoard);
//        int runningBlack = myAI.analyzeBoardBlack(myBoard, false);
//        System.out.println("white: " + runningWhite + " | black: " + runningBlack);
//        System.out.println("turn: " + myBoard.turn());
//        myBoard.printBoard();
//
//        assertEquals(3000, runningWhite);
//
//        myBoard.makeMove(sq(0, 3), sq(2, 3));
//        myBoard.makeMove(sq(4, 2), sq(2, 2));
//
//        /* Shouldn't make a difference for this particular position*/
//        runningWhite = myAI.analyzeBoardWhite(myBoard);
//        assertTrue(runningWhite > 3000);
//
//        myBoard.makeMove(sq(3, 8), sq(3, 5));
//        assertNotEquals(runningBlack, runningWhite);
//
//        try {
//            myBoard.makeMove(sq(8, 5), sq(5, 5));
//            System.out.println("wait no");
//        } catch (IllegalArgumentException e) {
            myBoard.printBoard();
            System.out.println(sq(8, 5) + " to " + sq(5, 5)
                    + " was actually illegal, so we threw and exception and caught it");
            System.out.println();
//            myBoard.makeMove(sq(4, 3), sq(4, 2));
//            myBoard.makeMove(sq(8, 3), sq(4, 3));
//        }
//
//        runningWhite = myAI.analyzeBoardWhite(myBoard);
//        runningBlack = myAI.analyzeBoardBlack(myBoard, false);
//        System.out.println("white: " + runningWhite + " | black: " + runningBlack);
//        System.out.println("turn: " + myBoard.turn());
//        myBoard.printBoard();
//        assertTrue(runningBlack * -1 > runningWhite);
//
//        myBoard.makeMove(sq(2, 2), sq(4, 2));
//        runningWhite = myAI.analyzeBoardWhite(myBoard);
//        runningBlack = myAI.analyzeBoardBlack(myBoard, false);
//        System.out.println("white: " + runningWhite + " | black: " + runningBlack);
//        System.out.println("turn: " + myBoard.turn());
//        myBoard.printBoard();
//        assertTrue(runningWhite > runningBlack * -1);
//
//        myBoard.makeMove(sq(3, 0), sq(3, 3));
//        runningWhite = myAI.analyzeBoardWhite(myBoard);
//        runningBlack = myAI.analyzeBoardBlack(myBoard, false);
//        System.out.println("white: " + runningWhite + " | black: " + runningBlack);
//        System.out.println("turn: " + myBoard.turn());
//        myBoard.printBoard();
//        assertTrue(runningWhite < runningBlack * -1);
//
//        myBoard.makeMove(sq(4, 2), sq(3, 2));
//        myBoard.makeMove(sq(4, 1), sq(3, 1));
//
//        runningWhite = myAI.analyzeBoardWhite(myBoard);
//        runningBlack = myAI.analyzeBoardBlack(myBoard, false);
//        System.out.println("white: " + runningWhite + " | black: " + runningBlack);
//        System.out.println("turn: " + myBoard.turn());
//        myBoard.printBoard();
//        assertEquals(2147483647, runningWhite);
//
//        myBoard.makeMove(sq(4, 4), sq(4, 2));
//        myBoard.makeMove(sq(3, 1), sq(4, 1));
//
//        runningWhite = myAI.analyzeBoardWhite(myBoard);
//        System.out.println("Target case");
//        runningBlack = myAI.analyzeBoardBlack(myBoard, false);
//        System.out.println("white: " + runningWhite + " | black: " + runningBlack);
//        System.out.println("turn: " + myBoard.turn());
//        myBoard.printBoard();
//        assertEquals(2147483647, runningWhite);
//        assertEquals(-2147483647, runningBlack);
//
//        myBoard.undo();
//        myBoard.undo();
//        myBoard.printBoard();
    }

    @Test
    public void testAI() {

        AI myAI = new AI(WHITE, null);
        AI oppAI = new AI(BLACK, null);
        Board myBoard = new Board();
        myAI.setTestBoard(myBoard);
        oppAI.setTestBoard(myBoard);

        Piece[][] theBoard = new Piece[][] {
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, BLACK, BLACK, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, WHITE},
                {BLACK, BLACK, BLACK, KING, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
        };
        myBoard.initializeTo(theBoard, WHITE);
        Move boobMove = myAI.findMove();
        myBoard.makeMove(boobMove);
        System.out.println(myBoard);
        assertEquals("white should have taken the win", WHITE, myBoard.winner());
        assertEquals(KING, myBoard.get(8, 4));
        myBoard.undo();

        theBoard = new Piece[][] {
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE},
                {BLACK, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE},
                {BLACK, WHITE, WHITE, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, BLACK},
                {BLACK, WHITE, WHITE, KING, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY},
                {BLACK, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE},
                {BLACK, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE, WHITE},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
                {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
        };

        myBoard.initializeTo(theBoard, BLACK);
        boobMove = oppAI.findMove();
        myBoard.makeMove(boobMove);
        assertEquals("The win should have been blocked", BLACK, myBoard.get(8, 4));
        System.out.println(myBoard);

        Piece[][] newBoard = initializeBoardFromString(
                "- - - - - B - - - \n"
                + "- - - - B - - - - \n"
                + "- - - - W - W - - \n"
                + "B - W - K - - - - \n"
                + "B B - - - - B - - \n"
                + "B - - - - B - - - \n"
                + "- - - - B - - - - \n"
                + "- - - - - - - - - \n"
                + "- - - - - - - - - ");

        myBoard.initializeTo(newBoard, BLACK);
        boobMove = oppAI.findMove();
        System.out.println(myBoard);
        myBoard.makeMove(boobMove);
        System.out.println(myBoard);
    }

    @Test
    public void testAI2() {
        AI myAI = new AI(WHITE, null);
        AI oppAI = new AI(BLACK, null);
        Board myBoard = new Board();
        myAI.setTestBoard(myBoard);
        oppAI.setTestBoard(myBoard);

        while (myBoard.winner() == null) {
            System.out.println("Black's move");

            myBoard.printBoard();
            myBoard.makeMove(oppAI.findMove());
            if (myBoard.winner() == null) {
                System.out.println("White's move");
                myBoard.printBoard();
                myBoard.makeMove(myAI.findMove());
            }
        }
        System.out.println("Winner is: " + myBoard.winner());
        myBoard.printBoard();

    }

    @Test
    public void myTextTests() {
        AI myAI = new AI(WHITE, null);
        AI oppAI = new AI(BLACK, null);
        Board myBoard = new Board();
        myAI.setTestBoard(myBoard);
        oppAI.setTestBoard(myBoard);

        myBoard.initializeTo(initializeBoardFromString("- - - - B B - - - \n" +
                "- - - B B - - - - \n" +
                "- - - - W - - - - \n" +
                "B - - - W - W - B \n" +
                "B - K - - W - B B \n" +
                "- - B W - - - - B \n" +
                "- - - - W B - - - \n" +
                "- - - - - - - - - \n" +
                "- B W - W - - - - "), BLACK);

//        System.out.println(oppAI.analyzeBoardBlack(myBoard, false));
//        System.out.println(myAI.analyzeBoardWhite(myBoard));

        myBoard.makeMove(oppAI.findMove());
        System.out.println(myBoard);

    }
}



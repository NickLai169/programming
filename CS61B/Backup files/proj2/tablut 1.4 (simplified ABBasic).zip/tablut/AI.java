package tablut;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static java.lang.Math.*;

import static tablut.Square.exists;
import static tablut.Square.sq;
import static tablut.Board.THRONE;
import static tablut.Piece.*;
import static java.lang.Integer.*;

//MY VERSION 1.3
/** A Player that automatically generates moves.
 *  @author Definite-Not-Nick
 */
class AI extends Player {

    /** A position-score magnitude indicating a win (for white if positive,
     *  black if negative). */
    private static final int WINNING_VALUE = Integer.MAX_VALUE - 20;
    /** A position-score magnitude indicating a forced win in a subsequent
     *  move.  This differs from WINNING_VALUE to avoid putting off wins. */
    private static final int WILL_WIN_VALUE = Integer.MAX_VALUE - 40;
    /** A magnitude greater than a normal value. */
    private static final int INFTY = Integer.MAX_VALUE;

    /** A new AI with no piece or controller (intended to produce
     *  a template). */
    AI() {
        this(null, null);
    }

    /** A new AI playing PIECE under control of CONTROLLER. */
    AI(Piece piece, Controller controller) {
        super(piece, controller);
    }

    @Override
    Player create(Piece piece, Controller controller) {
        return new AI(piece, controller);
    }

    @Override
    String myMove() {
        if (_controller.board().winner() != null || _controller.board().turn() != _myPiece) {
            return "Aye bro this shit fucked";
        }
        String retString = findMove().toString();
        System.out.println(retString);
        return retString; // FIXME
    }

    @Override
    boolean isManual() {
        return false;
    }

    Board _testBoard;
    /** Just for testing sake, this sets my board to whichever board is passed in
     * @param board the board that was passed in
     */
    public void setTestBoard(Board board) {
        _testBoard = board;
    }

    /** Return a move for me from the current position, assuming there
     *  is a move. */
    public Move findMove() {
//        Board b = new Board(board()); //REMEMBER TO UNCOMMENT
        Board b = _testBoard;
        _lastFoundMove = null;
        if (_myPiece == WHITE) {
            findMove(b, 2, true, 1, -1 * MAX_VALUE, MAX_VALUE);
//            findMove(b, maxDepth(b, WHITE), true, 1, -1 * MAX_VALUE, MAX_VALUE);
        } else {
            findMove(b, 2, true, -1, -1 * MAX_VALUE, MAX_VALUE);
//            findMove(b, maxDepth(b, BLACK), true, -1, -1 * MAX_VALUE, MAX_VALUE);
        }
        // FIXME: FIXED?
        System.out.println(_lastFoundMove);
        return _lastFoundMove;
    }

    /** The move found by the last call to one of the ...FindMove methods
     *  below. */
    private Move _lastFoundMove;

    /** Find a move from position BOARD and return its value, recording
     *  the move found in _lastFoundMove iff SAVEMOVE. The move
     *  should have maximal value or have value > BETA if SENSE==1,
     *  and minimal value or value < ALPHA if SENSE==-1. Searches up to
     *  DEPTH levels.  Searching at level 0 simply returns a static estimate
     *  of the board value and does not set _lastMoveFound. */
    public int findMove(Board board, int depth, boolean saveMove,
                        int sense, int alpha, int beta) { //Change back to private
        /* Just analyse the board if the depth is 0*/
        if (depth == 0) {
            return analyseBoardBasics(board);
        }

        if (board.winner() == BLACK) {
            System.out.println("BLACK WON! Depth: " + depth);
            return -1 * WINNING_VALUE;
        } else if (board.winner() == WHITE) {
            System.out.println("WHITE WON! Depth: " + depth);
            return WINNING_VALUE;
        }

        int tempVal;
        Move bestMove = null;
        if (sense == 1) {
            /* I am white*/
            List<Move> whiteMoves = board.legalMoves(WHITE);
            if (whiteMoves.size() == 0) {
                return -1 * WINNING_VALUE;
            }
            tempVal = -1 * WINNING_VALUE;
            for (Move moves: whiteMoves) {
                Board copyBoard = new Board(board);
                copyBoard.setTurn(WHITE);
                copyBoard.makeMove(moves);
                if (!copyBoard.repeatedPosition()) {
                    tempVal = Math.max(tempVal, findMove(copyBoard, depth - 1, false, -1, alpha, beta) - 20);
                    if (tempVal > alpha || bestMove == null) {
                        bestMove = moves;
                    }
                    int prevAlpha = alpha;
                    alpha = Math.max(alpha, tempVal);
                    if (alpha >= beta) {
                        break;
                    }
                }
            }
        } else {
            /* I am black*/
            List<Move> blackMoves = board.legalMoves(BLACK);
            tempVal = WINNING_VALUE;
            if (blackMoves.size() == 0) {
                return WINNING_VALUE;
            }
            for (Move moves: blackMoves) {
                Board copyBoard = new Board(board);
                copyBoard.setTurn(BLACK);
                copyBoard.makeMove(moves);
                tempVal = Math.min(tempVal, findMove(copyBoard, depth - 1, false, 1, alpha, beta) + 20);

                if (tempVal < beta || bestMove == null) {
                    bestMove = moves;
                }
                int prevBeta = beta;
                beta = Math.min(beta, tempVal);
                if (alpha >= beta) {
                    break;
                }
            }
        }
        if (saveMove) {
            _lastFoundMove = bestMove;
            System.out.println(_lastFoundMove);
        }
        return tempVal; // FIXME: FIXED?
    }

    /** Analyses a flat board for white, does not consider going deeper at all.
     * Assumes that it's white's turn right now.
     * @return integer representing the board position advantageness for white
     */
    public int analyzeBoardWhite(Board board) {
        System.out.println("this should never happen");
        Board myBoard = new Board(board);

        if (board.winner() == WHITE) {
            return WINNING_VALUE;
        }
        /* Checks to see if the piece can win on next move*/
        for (int dir = 0; dir < 4; dir += 1) {
            if (canReachEdge(myBoard.board(), myBoard.kingPosition(), dir)) {
                return WILL_WIN_VALUE;
            }
        }

        /* Checks for unstoppable wins*/
        for (Move moves: myBoard.legalMoves(WHITE)) {
            myBoard.setTurn(WHITE);
            myBoard.makeMove(moves);
            if (!(analyzeBoardBlack(myBoard, true) <= ((-1 * WILL_WIN_VALUE)- 50))
                    && !myBoard.repeatedPosition()) {
                if (!(myBoard.kingPosition() == board.kingPosition())) {
                    int counter = 0;
                    for (int dir = 0; dir < 4; dir += 1) {
                        if (canReachEdge(myBoard.board(), myBoard.kingPosition(), dir)) {
                            counter += 1;
                        }
                    }
                    if (counter >= 2) {
                        return WILL_WIN_VALUE - 20;
                    }
                }
            }
            myBoard.undo();
        }
        return analyseBoardBasics(myBoard);
    }

    /** Analyses a flat board for black, does not consider going deeper at all.
     * Assumes that it's black's turn right now.
     * @return integer representing the board position advantageness for black
     */
    public int analyzeBoardBlack(Board board, boolean calledByWhite) {
        System.out.println("this should never happen");
        /* Checks for opportunities to capture the king*/
        int retVal = MAX_VALUE;
        Board myBoard = new Board(board);
        for (Move moves: myBoard.legalMoves(BLACK)) {
            myBoard.setTurn(BLACK);
            myBoard.makeMove(moves);

            if (myBoard.winner() == BLACK) {
                return -1 * WILL_WIN_VALUE;
            }
            myBoard.undo();
        }

        if (calledByWhite) {
            return analyseBoardBasics(board);
        }

        for (Move moves: myBoard.legalMoves(BLACK)) {
            myBoard.setTurn(BLACK);
            myBoard.makeMove(moves);

            if (!myBoard.repeatedPosition()) {
                retVal = Math.min(analyseBoardBasics(myBoard), retVal);
            }
            myBoard.undo();
        }
        return retVal;
    }

    /** A simple (ha ha! I'm fucking hilarious) method which calculates roughly
     * which side has advantage and whatnot for one frame of the game. Note that
     * this method does not take into consideration who's turn it is.
     * @param board the board
     * @return an integer value representing the desirability of the board for white.
     */
    public int analyseBoardBasics(Board board) {
        HashSet<Square> whitePieceLocations = board.pieceLocations(WHITE);
        HashSet<Square> blackPieceLocations = board.pieceLocations(BLACK);

        /* Check to see if anybody has won yet*/
        if (board.winner() == WHITE) {
            return MAX_VALUE;
        } else if (board.winner() == BLACK) {
            return MIN_VALUE;
        }

        Square kingPos = board.kingPosition();

        int retVal = 0;
        retVal += whitePieceLocations.size() * 30000;
        retVal -= blackPieceLocations.size() * 15000;
//        System.out.println("Post piece math: " + retVal);

        /* Check king walking steps to get to edge*/
        retVal += kingWalker(board.board(), kingPos, 2430, new HashSet<Square>(), 4);

//        System.out.println("Post king walk: " + retVal);
        return retVal;
    }

    /** Analyzes the board assuming it's white's turn first, checking the result of
     * analyseBoardBasics() for each taking opportunity, as well as comparing that
     * against the situation in which nothing is taken and the board is left as is.
     * @param board the board
     * @return integer value denoting the desireability of the board for white
     */
    public int analyseBBwhite(Board board) {
        int retVal = -1 * MAX_VALUE;
        int noCapVal = -1 * MAX_VALUE;
        Board copyBoard = new Board(board);
        HashSet<Square> blackPieceLocations = board.pieceLocations(BLACK);

        /* Considers all the moves for white*/
        for (Move move: copyBoard.legalMoves(WHITE)) {
            copyBoard = new Board(board);
            copyBoard.setTurn(WHITE);
            copyBoard.makeMove(move);

            if (copyBoard.winner() == WHITE) {
                return WILL_WIN_VALUE;
            }

            if (!copyBoard.repeatedPosition()) {
                /* If something's been captured*/
                int capturedNum = blackPieceLocations.size() - copyBoard.pieceLocations(BLACK).size();
                int tempNum;
                if (capturedNum > 0) {
                    tempNum = (int) Math.pow(2, capturedNum - 1);
                    tempNum *= 600;
                    retVal = Math.max(analyseBoardBasics(copyBoard) + tempNum, retVal);
                } else {
                    noCapVal = Math.max(analyseBoardBasics(copyBoard), noCapVal);
                }
            }
        }

        return Math.max(retVal, noCapVal);
    }

    /** Analyzes the board assuming it's black's turn first, checking the result of
     * analyseBoardBasics() for each taking opportunity, as well as comparing that
     * against the situation in which nothing is taken and the board is left as is.
     * @param board the board
     * @return integer value denoting the desireability of the board for white
     */
    public int analyseBBblack(Board board) {
        int retVal = MAX_VALUE;
        int noCapVal = MAX_VALUE;
        Board copyBoard = new Board(board);
        HashSet<Square> whitePieceLocations = board.pieceLocations(WHITE);

        /* Considers all the moves for black*/
        for (Move move: copyBoard.legalMoves(BLACK)) {
            copyBoard = new Board(board);
            copyBoard.setTurn(BLACK);
            copyBoard.makeMove(move);

            if (copyBoard.winner() == BLACK) {
                return -1 * WILL_WIN_VALUE;
            }

            /* If something's been captured*/
            if (!copyBoard.repeatedPosition()) {
                int capturedNum = whitePieceLocations.size() - copyBoard.pieceLocations(WHITE).size();
                int tempNum;
                if (capturedNum > 0) {
                    tempNum = (int) Math.pow(2, capturedNum - 1);
                    tempNum *= 1500;
                    retVal = Math.min(analyseBoardBasics(copyBoard) - tempNum, retVal);
                } else {
                    noCapVal = Math.min(analyseBoardBasics(copyBoard), noCapVal);
                }
            }
        }
        return Math.min(retVal, noCapVal);
    }

    /** A function that analyses the king's pathways to victory, assuming the board
     * remains as it is for every move with only the king moving. Starts off at
     * currNum = 128. It's really just the programming "eyeballing" it :P. Note that
     * this is only really useful if you cannot manoeuvre yourself to a fork on your
     * immediate next turn. It's really only just a vague heuristic that symbolises
     * how 'open' the board is for the king.
     * @param board is the current board state
     * @param kingSquare is the square the king is on
     * @param currNum the current score value of this branch
     * @return the sum of the branches' worth
     */
    public int kingWalker(Piece[][] board, Square kingSquare, int currNum, HashSet<Square> visited, int prevDir) {
        if (currNum <= 29) {
            return 0;
        }
        if (visited.contains(kingSquare)) {
            return 0;
        }

        visited.add(kingSquare);
        int retVal = 0;
        Piece[][] copiedBoard = copyBoard(board);
        int[] changeRow = new int[] {-1, 0, 1, 0};
        int[] changeCol = new int[] {0, 1, 0, -1};

//        System.out.println(kingSquare.row() + ", " + kingSquare.col() + " | currNum: " + currNum);
        for (int dir = 0; dir < 4; dir += 1) {
            if (canReachEdge(copiedBoard, kingSquare, dir)) {
//                System.out.println("boom " + currNum);
                retVal += currNum;
            } else {
                int newRow = kingSquare.row() + changeRow[dir];
                int newCol = kingSquare.col() + changeCol[dir];
                if (newRow < copiedBoard.length && newRow > -1
                        && newCol < copiedBoard[0].length && newCol > -1
                        && copiedBoard[newRow][newCol] == EMPTY) {
                    copiedBoard[newRow][newCol] = KING;
                    copiedBoard[kingSquare.row()][kingSquare.col()] = EMPTY;

                    HashSet<Square> cloneVisited = (HashSet<Square>) visited.clone();

                    if (prevDir == dir) {
                        retVal += kingWalker(copiedBoard, sq(newCol, newRow), currNum, visited, dir);
                    } else {
                        retVal += kingWalker(copiedBoard, sq(newCol, newRow), currNum / 3, visited, dir);
                    }
                    copiedBoard = copyBoard(board);
                }
            }
        }

        return retVal;
    }

    /** Method that simply checks whether the king can reach the edge if it
     * continued in the direction (dir) provided.
     * @param board the board
     * @param kingSquare the square which denotes the position of the king
     * @param dir the direction in which the king may travel
     * @return true or false depending on whether the king is able to reach
     * the edge
     */
    public boolean canReachEdge(Piece[][] board, Square kingSquare, int dir) {
        Piece[][] myBoard = copyBoard(board);
        int[] changeRow = new int[] {-1, 0, 1, 0};
        int[] changeCol = new int[] {0, 1, 0, -1};
        int rowPos = kingSquare.row() + changeRow[dir];
        int colPos = kingSquare.col() + changeCol[dir];

        while (rowPos < board.length && rowPos > -1
                && colPos < board[0].length && colPos > -1) {
            if (myBoard[rowPos][colPos] != EMPTY) {
                return false;
            }
            rowPos += changeRow[dir];
            colPos += changeCol[dir];
        }
        return true;
    }

    /** Return a heuristically determined maximum search depth
     *  based on characteristics of BOARD. */
    private static int maxDepth(Board board, Piece turn) {
        int numMoves = board.legalMoves(turn).size();
        int retNum = 3;
        if (numMoves < 50) {
            retNum = 4;
        }
        return retNum; // FIXME: FIXED?
    }

    /** Return a heuristic value for BOARD. */
    private int staticScore(Board board) {
        return analyseBoardBasics(board);  // FIXME: FIXED
    }

    // FIXME: More here.
    public Piece[][] copyBoard(Piece[][] board) {
        Piece[][] retBoard = new Piece[board.length][board[0].length];

        for (int row = 0; row < board.length; row += 1) {
            for (int col = 0; col < board[0].length; col += 1) {
                retBoard[row][col] = board[row][col];
            }
        }

        return retBoard;
    }
}
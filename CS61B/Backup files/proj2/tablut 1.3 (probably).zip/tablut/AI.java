package tablut;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static java.lang.Math.*;

import static tablut.Square.exists;
import static tablut.Square.sq;
import static tablut.Board.THRONE;
import static tablut.Piece.*;
import static java.lang.Integer.*;

/** A Player that automatically generates moves.
 *  @author Definite-Not-Nick
 */
class AI extends Player {

    /** A position-score magnitude indicating a win (for white if positive,
     *  black if negative). */
    private static final int WINNING_VALUE = Integer.MAX_VALUE - 20;
    /** A position-score magnitude indicating a forced win in a subsequent
     *  move.  This differs from WINNING_VALUE to avoid putting off wins. */
    private static final int WILL_WIN_VALUE = Integer.MAX_VALUE - 40;
    /** A magnitude greater than a normal value. */
    private static final int INFTY = Integer.MAX_VALUE;

    /** A new AI with no piece or controller (intended to produce
     *  a template). */
    AI() {
        this(null, null);
    }

    /** A new AI playing PIECE under control of CONTROLLER. */
    AI(Piece piece, Controller controller) {
        super(piece, controller);
    }

    @Override
    Player create(Piece piece, Controller controller) {
        return new AI(piece, controller);
    }

    @Override
    String myMove() {
        if (_controller.board().winner() != null || _controller.board().turn() != _myPiece) {
            return "Aye bro this shit fucked";
        }

        return ""; // FIXME
    }

    @Override
    boolean isManual() {
        return false;
    }

    /** Return a move for me from the current position, assuming there
     *  is a move. */
    public Move findMove() { //change back to private...?
//        Board b = new Board(board());
        Board b = testBoard;
        _lastFoundMove = null;
        int mySense;
        if (_myPiece == WHITE){
            mySense = 1;
        } else {
            mySense = -1;
        }
        findMove(b, 2, true, mySense, -1 * MAX_VALUE, MAX_VALUE);
        // FIXME
        return _lastFoundMove;
    }

    /** The move found by the last call to one of the ...FindMove methods
     *  below. */
    private Move _lastFoundMove;

    /** Find a move from position BOARD and return its value, recording
     *  the move found in _lastFoundMove iff SAVEMOVE. The move
     *  should have maximal value or have value > BETA if SENSE==1,
     *  and minimal value or value < ALPHA if SENSE==-1. Searches up to
     *  DEPTH levels.  Searching at level 0 simply returns a static estimate
     *  of the board value and does not set _lastMoveFound. */
    public int findMove(Board board, int depth, boolean saveMove,
                        int sense, int alpha, int beta) { //Change back to private
        /* Just analyse the board if the depth is 0*/
        if (depth == 0) {
            if (sense == 1) {
                int tempVal = analyzeBoardWhite(board);
//                System.out.println("Depth: " + depth + " | tempVal: " + tempVal + " | I am " + sense);
                return tempVal;
            } else {
                int tempVal = analyzeBoardBlack(board, false);
//                System.out.println("Depth: " + depth + " | tempVal: " + tempVal + " | I am " + sense);
                return tempVal;
            }
        }

        int tempVal;
        Move bestMove = null;
        if (sense == 1) {
            /* I am white*/
            List<Move> whiteMoves = board.legalMoves(WHITE);
            tempVal = -1 * WINNING_VALUE;
            for (Move moves: whiteMoves) {
                Board copyBoard = new Board(board);
                copyBoard.setTurn(WHITE);
                copyBoard.makeMove(moves);
                tempVal = Math.max(tempVal, findMove(copyBoard, depth - 1, false, -1, alpha, beta));
                if (tempVal > alpha || bestMove == null) {
                    bestMove = moves;
//                    System.out.println("Sense: " + sense + " | bestMove: " + bestMove
//                            + "tempVal is now: " + Math.max(alpha, tempVal));
                }
                int prevAlpha = alpha;
                alpha = Math.max(alpha, tempVal);
                if (alpha >= beta) {
                    break;
                }
            }
        } else {
            /* I am black*/
            List<Move> blackMoves = board.legalMoves(BLACK);
            tempVal = WINNING_VALUE;
            for (Move moves: blackMoves) {
                Board copyBoard = new Board(board);
                copyBoard.setTurn(BLACK);
                copyBoard.makeMove(moves);
                tempVal = Math.min(tempVal, findMove(copyBoard, depth - 1, false, 1, alpha, beta));

                if (tempVal < beta || bestMove == null) {
                    bestMove = moves;
//                    System.out.println("Sense: " + sense + " | bestMove: " + bestMove
//                            + " | tempVal is now: " + Math.min(beta, tempVal));
                }
                int prevBeta = beta;
                beta = Math.min(beta, tempVal);
                if (alpha >= beta) {
                    break;
                }
            }
        }
        if (saveMove) {
            _lastFoundMove = bestMove;
        }
//        System.out.println("Depth: " + depth + " | tempVal: " + tempVal + " | I am " + sense);
        return tempVal; // FIXME: FIXED?
    }

    /** Analyses a flat board for white, does not consider going deeper at all.
     * Assumes that it's white's turn right now.
     * @return integer representing the board position advantageness for white
     */
    public int analyzeBoardWhite(Board board) {
        List<Move> myMoves = board.legalMoves(WHITE);
        List<Move> theirMoves = board.legalMoves(BLACK);
        HashSet<Square> whitePieceLocations = board.pieceLocations(WHITE);
        HashSet<Square> blackPieceLocations = board.pieceLocations(BLACK);
        Square kingPos = board.kingPosition();
        Piece[][] theBoard = copyBoard(board.board());

        /* Check to see if I've already won*/
        if (board.winner() == WHITE) {
            return WINNING_VALUE;
        }

        /* Checks to see if you can win on next move*/
        for (Move moves: myMoves) {
            if (moves.from() == kingPos) {
                if (moves.to().col() == 0 || moves.to().col() == 8
                        || moves.to().row() == 0 || moves.to().row() == 8) {
                    theBestMove = moves;
                    return WINNING_VALUE - 20;
                }
            }
        }

        /* Checks to see if you can move into an unstoppable win*/
        Board copyBoard = new Board(board);
        int temp = 0;
        for (Move moves: myMoves) {
            if (moves.from() == kingPos) {
                temp += 1;
                copyBoard.setTurn(WHITE);
                copyBoard.makeMove(moves);
                if (analyzeBoardBlack(copyBoard, true) >= WINNING_VALUE - 1000
                        && !copyBoard.repeatedPosition()) {
                    theBestMove = moves;
                    return WILL_WIN_VALUE - 20;
                }
                copyBoard.undo();
            }
        }

        return analyseBBwhite(myMoves, theirMoves, whitePieceLocations, blackPieceLocations, copyBoard, kingPos);
    }

    /** Analyses a flat board for black, does not consider going deeper at all.
     * Assumes that it's black's turn right now.
     * @return integer representing the board position advantageness for black
     */
    public int analyzeBoardBlack(Board board, boolean calledByWhite) {
        Board copyBoard = new Board(board);
        List<Move> myMoves = board.legalMoves(BLACK);
        List<Move> theirMoves = board.legalMoves(WHITE);
        HashSet<Square> whitePieceLocations = board.pieceLocations(WHITE);
        HashSet<Square> blackPieceLocations = board.pieceLocations(BLACK);
        Square kingPos = board.kingPosition();
        Piece[][] theBoard = copyBoard(board.board());

        /* Check to see if I've won*/
        if (board.winner() == BLACK) {
            return (-1 * WINNING_VALUE);
        }

        /* Check to see if you can win on the next move*/
        for (Move moves: myMoves) {
            copyBoard.setTurn(BLACK);
            copyBoard.makeMove(moves);
            if (copyBoard.winner() == BLACK) {
                return (-1 * WINNING_VALUE) + 20;
            }
            copyBoard = new Board(board);
        }

        /* Check to see if white has an unstoppable win by seeing how many
        * edges the king can reach right now*/
        int edgeCounter = 0;
        for (int dir = 0; dir < 4; dir += 1) {
            if (canReachEdge(board.board(), board.kingPosition(), dir)) {
                edgeCounter += 1;
            }
        }
        copyBoard = new Board(board);
        if (edgeCounter >= 2) {
            return WILL_WIN_VALUE;
        }
        /* What we should do since the win is stoppable*/
        if (edgeCounter == 1) {
            boolean didIEverStopHim = false;
            Move didIEverStopHimMove = null;
            for (Move moves: myMoves) {
                boolean stopHim = false;
                copyBoard.setTurn(BLACK);
                copyBoard.makeMove(moves);
                for (int dir = 0; dir < 4; dir += 1) {
                    stopHim = stopHim || canReachEdge(copyBoard.board(), copyBoard.kingPosition(), dir);
                }
                if (!stopHim) {
                    didIEverStopHim = true;
                    didIEverStopHimMove = moves;
                }
                copyBoard.undo();
            }
            if (didIEverStopHim) {
                copyBoard.setTurn(BLACK);
                copyBoard.makeMove(didIEverStopHimMove);
                theBestMove = didIEverStopHimMove;
                System.out.println(analyseBBblack(theirMoves, myMoves, whitePieceLocations, blackPieceLocations, copyBoard, kingPos));
                return analyseBBblack(theirMoves, myMoves, whitePieceLocations, blackPieceLocations, copyBoard, kingPos);
            }
            return WILL_WIN_VALUE - 20;
        }

        if (calledByWhite) {
            return MIN_VALUE;
        }

        return analyseBBblack(theirMoves, myMoves, whitePieceLocations, blackPieceLocations, copyBoard, kingPos);
    }

    /** A simple (ha ha! I'm fucking hilarious) method which calculates roughly
     * which side has advantage and whatnot for one frame of the game. Note that
     * this method does not take into consideration who's turn it is.
     * @param board the board
     * @return an integer value representing the desirability of the board for white.
     */
    public int analyseBoardBasics(Board board) {
        List<Move> whiteMoves = board.legalMoves(WHITE);
        List<Move> blackMoves = board.legalMoves(BLACK);
        HashSet<Square> whitePieceLocations = board.pieceLocations(WHITE);
        HashSet<Square> blackPieceLocations = board.pieceLocations(BLACK);
        Piece[][] theBoard = copyBoard(board.board());

        Square kingPos = board.kingPosition();

        int retVal = 0;
        retVal += whitePieceLocations.size() * 3000;
        retVal -= blackPieceLocations.size() * 1500;
//        System.out.println("Post piece math: " + retVal);

        /* Check black capturing opportunities*/
        for (Move move: blackMoves) {
            Piece[][] tempBoard = copyBoard(board.board());
            for (int dir = 0; dir < 4; dir += 1) {
                Square oppositeSquare = move.to().rookMove(dir, 2);
                Square betweenSquare = move.to().rookMove(dir, 1);
                int combo = 1;
                if (betweenSquare != null && oppositeSquare != null) {
                    tempBoard[move.to().row()][move.to().col()]
                            = tempBoard[move.from().row()][move.from().col()];
                    if (board.canCapture(move.to(), betweenSquare, oppositeSquare, tempBoard)) {
                        retVal -= 800 * combo;
                        combo += 1;
                        if (tempBoard[betweenSquare.row()][betweenSquare.col()] == KING) {
                            retVal -= 1600;
                        }
                    }
                }
            }
        }
//        System.out.println("Post black check: " + retVal);

        /* Check white capturing opportunities*/
        for (Move move: whiteMoves) {
            Piece[][] tempBoard = copyBoard(board.board());
            for (int dir = 0; dir < 4; dir += 1) {
                Square oppositeSquare = move.to().rookMove(dir, 2);
                Square betweenSquare = move.to().rookMove(dir, 1);
                int combo = 0;
                if (betweenSquare != null && oppositeSquare != null) {
                    tempBoard[move.to().row()][move.to().col()]
                            = tempBoard[move.from().row()][move.from().col()];
                    if (board.canCapture(move.to(), betweenSquare, oppositeSquare, tempBoard)) {
                        combo += 1;
                        retVal += 400 * combo;
                    }
                }
            }
        }
//        System.out.println("Post white check: " + retVal);

        /* Check king walking steps to get to edge*/
        retVal += kingWalker(board.board(), kingPos, 243, new HashSet<Square>(), 4);

//        System.out.println("Post king walk: " + retVal);
        return retVal;
    }

    /** Analyzes the board assuming it's white's turn first, checking the result of
     * analyseBoardBasics() for each taking opportunity, as well as comparing that
     * against the situation in which nothing is taken and the board is left as is.
     * @param whiteMoves list of possible moves for white
     * @param blackMoves list of possible moves for black
     * @param whitePieceLocations location of all white pieces
     * @param blackPieceLocations location of all blackpieces
     * @param board the board
     * @param kingPos the square which denotes the king's position
     * @return integer value denoting the desireability of the board for white
     */
    public int analyseBBwhite(List<Move> whiteMoves, List<Move> blackMoves,
                              HashSet<Square> whitePieceLocations, HashSet<Square> blackPieceLocations,
                              Board board, Square kingPos) {
        int retVal = -1 * WINNING_VALUE;
        Move retValMove = null;
        int noCapVal = -1 * WINNING_VALUE;
        Move noCapValMove = null;
        int boardVal;

        /* Considers all the moves for white*/
        for (Move move: board.legalMoves(WHITE)) {
            for (int dir = 0; dir < 4; dir += 1) {
                Square oppositeSquare = move.to().rookMove(dir, 2);
                Square betweenSquare = move.to().rookMove(dir, 1);
                Board copyBoard = new Board(board);
                copyBoard.setTurn(WHITE);

                Piece[][] tempBoard = copyBoard(copyBoard.board());
                copyBoard.makeMove(move.from(), move.to());
                if (!copyBoard.repeatedPosition()) {
                    if (betweenSquare != null && oppositeSquare != null) {
                        tempBoard[move.to().row()][move.to().col()]
                                = tempBoard[move.from().row()][move.from().col()];
                        if (board.canCapture(move.to(), betweenSquare, oppositeSquare, tempBoard)) {
                            if (!copyBoard.repeatedPosition()) {
                                boardVal = analyseBoardBasics(copyBoard);
                                if (boardVal > retVal) {
                                    retValMove = move;
                                }
                                retVal = Math.max(retVal, boardVal);
                            }
                        } else {
                            int tempInt = analyseBoardBasics(copyBoard);
                            if (tempInt < noCapVal) {
                                noCapValMove = move;
                            }
                            noCapVal = Math.max(noCapVal, tempInt);
                        }
                    }
                }
            }
        }
        if (noCapVal < retVal) {
            theBestMove = noCapValMove;
        } else {
            theBestMove = retValMove;
        }
        return Math.max(retVal, noCapVal);
    }

    /** Analyzes the board assuming it's black's turn first, checking the result of
     * analyseBoardBasics() for each taking opportunity, as well as comparing that
     * against the situation in which nothing is taken and the board is left as is.
     * @param whiteMoves list of possible moves for white
     * @param blackMoves list of possible moves for black
     * @param whitePieceLocations location of all white pieces
     * @param blackPieceLocations location of all black pieces
     * @param board the board
     * @param kingPos the square which denotes the king's position
     * @return integer value denoting the desireability of the board for white
     */
    public int analyseBBblack(List<Move> whiteMoves, List<Move> blackMoves,
                              HashSet<Square> whitePieceLocations, HashSet<Square> blackPieceLocations,
                              Board board, Square kingPos) {
        int retVal = WINNING_VALUE;
        Move retValMove = null;
        int noCapVal = WINNING_VALUE;
        Move noCapValMove = null;
        int boardVal;


        /* Considers all the moves for black*/
        for (Move move: board.legalMoves(BLACK)) {
            for (int dir = 0; dir < 4; dir += 1) {
                Square oppositeSquare = move.to().rookMove(dir, 2);
                Square betweenSquare = move.to().rookMove(dir, 1);
                Board copyBoard = new Board(board);
                copyBoard.setTurn(BLACK);
                Piece[][] tempBoard = copyBoard(copyBoard.board());

//                System.out.println(copyBoard.repeatedPosition());
//                copyBoard.printBoard();
                copyBoard.makeMove(move.from(), move.to());
//                System.out.println(copyBoard.repeatedPosition());
//                copyBoard.printBoard();

                if (!copyBoard.repeatedPosition()) {
                    if (betweenSquare != null && oppositeSquare != null) {
                        tempBoard[move.to().row()][move.to().col()]
                                = tempBoard[move.from().row()][move.from().col()];
                        if (board.canCapture(move.to(), betweenSquare, oppositeSquare, tempBoard)) {
                            if (!copyBoard.repeatedPosition()) {
                                boardVal = analyseBoardBasics(copyBoard);
                                if (boardVal < retVal) {
                                    retValMove = move;
                                }
                                retVal = Math.min(retVal, boardVal);
                            }
                        } else {
                            int tempInt = analyseBoardBasics(copyBoard);
                            if (tempInt < noCapVal) {
                                noCapValMove = move;
                            }
                            noCapVal = Math.min(noCapVal, tempInt);
                        }
                    }
                }
            }
        }
        if (noCapVal < retVal) {
            theBestMove = noCapValMove;
        } else {
            theBestMove = retValMove;
        }
        return Math.min(retVal, noCapVal);
    }

    /** A function that analyses the king's pathways to victory, assuming the board
     * remains as it is for every move with only the king moving. Starts off at
     * currNum = 128. It's really just the programming "eyeballing" it :P. Note that
     * this is only really useful if you cannot manoeuvre yourself to a fork on your
     * immediate next turn. It's really only just a vague heuristic that symbolises
     * how 'open' the board is for the king.
     * @param board is the current board state
     * @param kingSquare is the square the king is on
     * @param currNum the current score value of this branch
     * @return the sum of the branches' worth
     */
    public int kingWalker(Piece[][] board, Square kingSquare, int currNum, HashSet<Square> visited, int prevDir) {
        if (currNum <= 2) {
            return 0;
        }
        if (visited.contains(kingSquare)) {
            return 0;
        }

        visited.add(kingSquare);
        int retVal = 0;
        Piece[][] copiedBoard = copyBoard(board);
        int[] changeRow = new int[] {-1, 0, 1, 0};
        int[] changeCol = new int[] {0, 1, 0, -1};

//        System.out.println(kingSquare.row() + ", " + kingSquare.col() + " | currNum: " + currNum);
        for (int dir = 0; dir < 4; dir += 1) {
            if (canReachEdge(copiedBoard, kingSquare, dir)) {
//                System.out.println("boom " + currNum);
                retVal += currNum;
            } else {
                int newRow = kingSquare.row() + changeRow[dir];
                int newCol = kingSquare.col() + changeCol[dir];
                if (newRow < copiedBoard.length && newRow > -1
                        && newCol < copiedBoard[0].length && newCol > -1
                        && copiedBoard[newRow][newCol] == EMPTY) {
                    copiedBoard[newRow][newCol] = KING;
                    copiedBoard[kingSquare.row()][kingSquare.col()] = EMPTY;

                    HashSet<Square> cloneVisited = (HashSet<Square>) visited.clone();

                    if (prevDir == dir) {
                        retVal += kingWalker(copiedBoard, sq(newCol, newRow), currNum, visited, dir);
                    } else {
                        retVal += kingWalker(copiedBoard, sq(newCol, newRow), currNum / 3, visited, dir);
                    }
                    copiedBoard = copyBoard(board);
                }
            }
        }

        return retVal;
    }

    /** Method that simply checks whether the king can reach the edge if it
     * continued in the direction (dir) provided.
     * @param board the board
     * @param kingSquare the square which denotes the position of the king
     * @param dir the direction in which the king may travel
     * @return true or false depending on whether the king is able to reach
     * the edge
     */
    public boolean canReachEdge(Piece[][] board, Square kingSquare, int dir) {
        Piece[][] myBoard = copyBoard(board);
        int[] changeRow = new int[] {-1, 0, 1, 0};
        int[] changeCol = new int[] {0, 1, 0, -1};
        int rowPos = kingSquare.row() + changeRow[dir];
        int colPos = kingSquare.col() + changeCol[dir];

        while (rowPos < board.length && rowPos > -1
                && colPos < board[0].length && colPos > -1) {
            if (myBoard[rowPos][colPos] != EMPTY) {
                return false;
            }
            rowPos += changeRow[dir];
            colPos += changeCol[dir];
        }
        return true;
    }

    /** Return a heuristically determined maximum search depth
     *  based on characteristics of BOARD. */
    private static int maxDepth(Board board) {
        return 4; // FIXME?
    }

    /** Return a heuristic value for BOARD. */
    private int staticScore(Board board) {
        return 0;  // FIXME
    }

    // FIXME: More here.
    public Piece[][] copyBoard(Piece[][] board) {
        Piece[][] retBoard = new Piece[board.length][board[0].length];

        for (int row = 0; row < board.length; row += 1) {
            for (int col = 0; col < board[0].length; col += 1) {
                retBoard[row][col] = board[row][col];
            }
        }

        return retBoard;
    }

    Board testBoard;
    public void setTestBoard(Board board) {
        testBoard = board;
    }

    Move theBestMove;
}
